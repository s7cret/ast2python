# AST2Python v0.6.0

Release date: 2026-04-27

## Added

- Pine2AST current-schema adapter for direct Program JSON and inspect-style envelopes with `ast`/`program` payloads.
- Integration fixtures from Pine2AST golden AST output and generated Python snapshot coverage.
- CLI coverage report enrichment: `node_kind_counts`, unsupported-node catalog, unsupported count, and `schema_supported_ratio`.
- Generated module smoke path exercised through the CLI with deterministic PineLib sample bars when local PineLib is importable.
- Unsupported node diagnostic catalog for known deferred Pine2AST node families.

## Changed

- Package version and generator milestone are now `0.6.0` / `v0.6.0`.
- AST descendant traversal ignores non-node metadata dictionaries such as `span` and diagnostics payloads.
- `validate` now reports schema-level unsupported-node catalog entries.

## Gates

- `python -m compileall ast2python tests scripts`
- `pytest -q`
- `mypy ast2python tests scripts/build_release.py`
- `./scripts/release_v0_6_0.sh`
