# AST2Python v0.5.0

Release date: 2026-04-27
Runtime contract: `1.4`

## Added

- Generated base interfaces under `ast2python.runtime_contract.generated_base`.
- `ast2python.emitters` compatibility package for emitter/import-manager split.
- Runtime-executing CLI smoke path using PineLib when importable, with deterministic sample bars and graceful skip if unavailable.
- Source-map executable-line coverage metric and tests enforcing at least 95% coverage on fixtures.
- Date helper lowering for `year`, `month`, `weekofyear`, `dayofmonth`, `dayofweek`, `hour`, `minute`, and `second` to `runtime.timefunc`.
- Reference policy diagnostics for array/map/matrix explicit copy and unsupported history.
- `request.security` mutable/reference capture-safety diagnostics with strict-mode failure.
- Strategy phase contract tests covering order-generation-only ownership.

## Changed

- Generated classes inherit from generated base interfaces.
- Strategy initialization attaches `StrategyContext` to runtime.
- Generated `run()` no longer calls `runtime.end_bar()`; the backtest/runtime loop owns bar commit and order fill phases.
- Generator metadata milestone is now `v0.5.0`.

## Validation

- `python -m compileall -q ast2python`
- `pytest -q`
- `mypy` when available through the release script
