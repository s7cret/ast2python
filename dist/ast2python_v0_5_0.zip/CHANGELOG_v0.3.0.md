# CHANGELOG v0.3.0

Release date: 2026-04-27
Runtime contract: `1.4`

## Added

- Added `ast2python.types.TypeInfo` and qualifier lattice helpers for deterministic type/qualifier metadata.
- Added metadata export for generated variable `TypeInfo` records.
- Added Pine v6 bool rejection for `na()`, `nz()`, and `fixnan()` with `P2A_BOOL_NA_OVERLOAD`.
- Added declaration metadata handling for `indicator()` and `library()` in addition to strategy declarations.
- Expanded strategy declaration field mapping for runtime contract v1.4 settings.
- Added named-argument-preserving `time()` and `time_close()` call generation.
- Added nested request diagnostics in strict and non-strict modes.
- Added input source default handling so `input.source(close)` keeps a runtime series reference.
- Added v0.3.0 tests for strategy declarations, input metadata, time/session calls, bool validation, unknown overload failures, nested request strict mode, and request lambda context.

## Changed

- Bumped package version and generator milestone metadata to `0.3.0` / `v0.3.0`.
- Unsupported/unknown call overloads continue to diagnose and fail before runtime rather than emitting fake success code.
- Generated metadata now includes declaration arguments for all declaration kinds.

## Deferred

- Full Pine overload database is still incremental; unknown overloads fail safely.
- Reference history support remains gated by PineLib runtime capability/configuration.
- Date helper lowering (`year`, `month`, etc.) is not complete in this milestone.
