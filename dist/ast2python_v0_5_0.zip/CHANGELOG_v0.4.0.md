# AST2Python v0.4.0

Released: 2026-04-27

## Added

- Control-flow generation for switch statements/expressions, while loops with max-iteration guards, and break/continue.
- User function and method declaration lowering with function-local scopes and last-expression returns.
- UDT dataclass and enum generation.
- UDT history member stability for forms such as `(obj[10]).field`.
- Visual recorder generation for plot/plotshape and visual object constructors/methods.
- Visual object id storage plus `P2A_VISUAL_OBJECT_USED_AS_VALUE` compile-time diagnostics for arithmetic/bool misuse.
- Source-map end-span fields and coverage generation ratio.
- v0.4 compile/snapshot tests covering switch, loops, functions, methods, UDT, enum, visual object storage, and misuse diagnostics.

## Changed

- Package/version metadata now reports `0.4.0` and generator milestone `v0.4.0`.
- README and release manifest updated for v0.4.0.

## Notes

- Generated code remains deterministic and fails during translation for unsupported or unsafe constructs rather than deferring failures to runtime.
- Pine2AST and PineLib were intentionally left untouched.
