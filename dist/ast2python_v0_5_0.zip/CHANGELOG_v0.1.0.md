# CHANGELOG v0.1.0

## Added

- initial `ast2python` package release
- runtime contract `1.4` target header and metadata output
- AST adapter for `kind`/`type`, `span`/`loc`, `items`/`children`/`body`, `arguments`/`args`
- diagnostics model with stable enterprise-facing codes
- naming registry, import manager, source map builder, code emitter, translation context, stable state-id generator
- translation support for declaration skeletons, literals, identifiers, member mappings, unary/binary/ternary expressions, variable declarations, reassignments, `if`, `for ... to ...`, `request.security`, and strategy declaration metadata
- CLI commands for `validate`, `translate`, `coverage`, and `smoke`
- pytest suite, release manifest, release script, reproducible zip build
