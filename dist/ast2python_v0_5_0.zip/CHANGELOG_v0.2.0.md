# CHANGELOG v0.2.0

Release date: 2026-04-27
Runtime contract: 1.4

## Added

- Tuple declaration generation with discard targets and per-series `set_current()` assignment.
- History reference generation for built-in runtime series and generated series.
- Inclusive Pine range loops via `pine_range`.
- Expanded member access generation for Pine namespaces required by v0.2.0 foundation work.
- Enriched input metadata extraction for optimizer/UI-facing fields.
- v0.2.0 indicator and strategy AST fixtures with compile assertions and source-map coverage checks.
- `generator_milestone` metadata marker.

## Improved

- Local declaration fallback for block/loop scopes.
- Deterministic state IDs remain stable for stateful TA calls and `request.security`.
- Generated code continues to fail at translation time for unsupported/invalid constructs.

## Deferred

- Full TypeInfo/qualifier resolver and overload matrix.
- Reference-type history semantics beyond supported series/history forms.
- Full visual object ID lifecycle generation for label/line/box/table.
- Complete generated template package split described in the long-form TZ architecture.
