# Runtime Contract v1.4 — PineLib ↔ AST2Python

**Дата:** 2026-04-27  
**Статус:** нормативный документ комплекта ТЗ  
**Проекты:** PineLib/PainLib Runtime, AST2Python, Pine2AST, bar-by-bar backtest engine  
**contract_version:** `1.4`

Этот документ формализует интерфейс между сгенерированным AST2Python-кодом и PineLib runtime. Если этот файл противоречит отдельным ТЗ, приоритет у этого файла.

---


## 0. Изменения v1.4

Версия v1.4 расширяет v1.3 следующими нормативными блоками:

1. Strategy execution/recalculation schedule.
2. IntrabarDataProvider и Bar Magnifier contract.
3. Sessions/timezone contract для `time()`/`time_close()`/calendar helpers.
4. Strategy declaration settings contract.
5. Type/Qualifier и reference semantics contract.
6. Input/visual/reference diagnostics.

---

## 1. Цель контракта

Обеспечить, чтобы:

1. AST2Python генерировал один и тот же исполняемый Python-код для одного и того же AST.
2. PineLib одинаково понимал `Series`, stateful-индикаторы, `request.security`, strategy orders и broker emulator.
3. Bar-by-bar execution совпадал с Pine Script v6: текущие значения доступны на текущем баре, история фиксируется только после commit закрытого бара.

---

## 2. Runtime ownership model

| Объект/действие | Ответственный |
|---|---|
| Создание `PineRuntime` | backtest engine или generated class wrapper |
| Регистрация built-in series `open/high/low/close/volume/time/time_close/bar_index` | `PineRuntime.begin_bar()` |
| Регистрация пользовательских series-переменных | generated code через `runtime.series(name, dtype)` |
| Вызов `set_current()` | generated code внутри `_process_bar()` |
| Вызов `commit_current()` | только `PineRuntime.end_bar()` |
| Хранение состояния EMA/RMA/ATR/RSI/MACD/... | `PineRuntime.indicator_state[state_id]` |
| Broker/order processing | `StrategyContext`, вызванный runtime/backtest loop |
| Загрузка HTF/LTF bars | `DataProvider` |

Запрещено: сгенерированный AST2Python-код не должен напрямую вызывать `commit_current()`.

---

## 3. Формат входных баров

### 3.1. Dataclass

```python
@dataclass(frozen=True)
class Bar:
    time: int          # Unix ms UTC, open time
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    time_close: int | None = None  # Unix ms UTC, close time
```

### 3.2. CSV

```csv
time,open,high,low,close,volume,time_close
1704067200000,42280.0,42500.0,42100.0,42450.0,1234.56,1704070799999
```

### 3.3. Parquet schema

```text
time: int64
open: float64
high: float64
low: float64
close: float64
volume: float64
time_close: int64 | null
symbol: string | null
timeframe: string | null
```

### 3.4. Timezone and ordering

1. Все timestamps — UTC Unix milliseconds.
2. Данные отсортированы по `time` ascending.
3. Дубли `time` запрещены.
4. Пропуски баров не исправляются автоматически, кроме явно заданного merge/gaps policy в `request.*`.
5. OHLC sanity-check обязателен: `high >= max(open, close)` и `low <= min(open, close)`.


### 3.5. Session/timezone contract

Runtime stores all `Bar.time`/`Bar.time_close` as UTC Unix milliseconds, but Pine calendar/session helpers must evaluate in the exchange timezone unless Pine explicitly passes another timezone.

Required interfaces:

```python
class SessionInfo(Protocol):
    raw: str                         # e.g. "0900-1700:12345"
    timezone: str                    # IANA name, e.g. "America/New_York"

class TimeFunctions(Protocol):
    def time(self, timeframe: str | None = None, session: str | None = None,
             timezone: str | None = None, *, runtime: PineRuntime): ...
    def time_close(self, timeframe: str | None = None, session: str | None = None,
                   timezone: str | None = None, *, runtime: PineRuntime): ...
```

Rules:

1. `timezone=None` means `runtime.syminfo.timezone`.
2. Session strings support day masks and overnight ranges.
3. Bars outside session return `na` for `time()`/`time_close()`.
4. Date helpers `year/month/weekofyear/dayofmonth/dayofweek/hour/minute/second` must use the same timezone rules.
5. DST must use IANA timezone names, not fixed offsets.

---

## 4. PineRuntime interface

```python
class PineRuntime(Protocol):
    contract_version: Literal["1.4"]
    bar_index: int
    current_bar: Bar | None
    chart_bars: list[Bar]
    series_registry: dict[str, Series]
    indicator_state: dict[str, object]
    syminfo: SymbolInfo
    timeframe: TimeframeInfo
    data_provider: DataProvider
    intrabar_provider: IntrabarDataProvider | None
    strategy: StrategyContext | None
    request_depth: int
    config: RuntimeConfig
    timefunc: TimeFunctions

    open: Series[float]
    high: Series[float]
    low: Series[float]
    close: Series[float]
    volume: Series[float]
    time: Series[int]
    time_close: Series[int]

    def begin_bar(self, bar: Bar) -> None: ...
    def end_bar(self) -> None: ...
    def series(self, name: str, dtype: str, initial=na) -> Series: ...
    def get_indicator_state(self, state_id: str, factory): ...
    def spawn_child_context(self, *, symbol: str, timeframe: str, namespace: str) -> "PineRuntime": ...
```

---

## 5. Series interface

```python
class Series(Generic[T]):
    name: str
    dtype: str

    @property
    def current(self) -> T: ...
    def set_current(self, value: T) -> None: ...
    def commit_current(self) -> None: ...
    def __getitem__(self, offset: int) -> T: ...
```

Rules:

1. `series[0]` equals `series.current`.
2. `series[1]` reads previous committed value, never the current uncommitted value.
3. Missing numeric/string/color/object history returns `na`.
4. Missing bool history returns `False`, because Pine v6 bool cannot be `na`.
5. `na()`, `nz()`, `fixnan()` must reject bool arguments.


### 5.1. Type/Qualifier and reference semantics contract

Runtime accepts optional TypeInfo metadata from generated code.

```python
@dataclass(frozen=True)
class TypeInfo:
    base_type: str
    qualifier: Literal["const", "input", "simple", "series"]
    is_reference_type: bool = False
    can_be_na: bool = True
    is_history_allowed: bool = True
```

Rules:

1. Qualifier ordering is `const < input < simple < series`.
2. Runtime helpers must reject invalid bool `na/nz/fixnan` usage.
3. Reference objects include arrays, maps, matrices, UDT instances and visual object ids.
4. Assignment of reference objects preserves identity unless an explicit copy function is called.
5. `var` reference objects keep identity across bars.
6. Reference history mode must be explicit in runtime config; unsupported reference history raises `PL_REFERENCE_HISTORY_UNSUPPORTED`.

---

## 6. Stateful TA function signature

Every stateful function called from generated code must support this shape:

```python
def ema(source, length, *, runtime: PineRuntime, state_id: str): ...
def rma(source, length, *, runtime: PineRuntime, state_id: str): ...
def atr(length, *, runtime: PineRuntime, state_id: str): ...
def rsi(source, length, *, runtime: PineRuntime, state_id: str): ...
def macd(source, fast, slow, signal, *, runtime: PineRuntime, state_id: str): ...
def supertrend(factor, atr_period, *, runtime: PineRuntime, state_id: str): ...
```

Batch mode may exist for tests, but generated code must use runtime mode.

### 6.1. `state_id` format

```python
state_id = f"L{line}_C{col_start}_{func_name}_{ordinal}"
```

Example:

```python
ema(runtime.close, 200, runtime=runtime, state_id="L42_C18_ema_1")
```

Nested calls use their own IDs:

```python
rsi(
    ema(runtime.close, 9, runtime=runtime, state_id="L50_C12_ema_1"),
    14,
    runtime=runtime,
    state_id="L50_C8_rsi_1",
)
```

---

## 7. `request.security` contract

### 7.1. Signature

```python
def security(
    symbol: str,
    timeframe: str,
    expression_callable: Callable[[PineRuntime], Any],
    *,
    runtime: PineRuntime,
    state_id: str,
    gaps: str = "barmerge.gaps_off",
    lookahead: str = "barmerge.lookahead_off",
    ignore_invalid_symbol: bool = False,
    currency: str | None = None,
    calc_bars_count: int | None = None,
): ...
```

### 7.2. Execution model

```python
def security(symbol, tf, expression_callable, *, runtime, state_id, **opts):
    if runtime.request_depth > 0 and not runtime.config.supports_nested_security:
        raise PineUnsupportedFeatureError("PL_UNSUPPORTED_NESTED_SECURITY")

    requested_bars = runtime.data_provider.get_bars(symbol, tf, runtime.range_start, runtime.range_end)
    request_rt = runtime.spawn_child_context(symbol=symbol, timeframe=tf, namespace=state_id)
    request_rt.request_depth = runtime.request_depth + 1

    requested_values = []
    for bar in requested_bars:
        request_rt.begin_bar(bar)
        requested_values.append(expression_callable(request_rt))
        request_rt.end_bar()

    merged = merge_requested_series_to_chart_bars(
        requested_values,
        requested_bars=requested_bars,
        chart_bars=runtime.chart_bars,
        gaps=opts.get("gaps", "barmerge.gaps_off"),
        lookahead=opts.get("lookahead", "barmerge.lookahead_off"),
    )
    return merged[runtime.bar_index]
```

Expression callable must use `request_rt.open/high/low/close/...`, not chart runtime series.

---

## 8. DataProvider contract

```python
class DataProvider(Protocol):
    def get_bars(
        self,
        symbol: str,
        timeframe: str,
        start: int | None,
        end: int | None,
        *,
        max_bars: int | None = None,
    ) -> list[Bar]: ...
```

Rules:

1. Returned bars follow the common Bar format.
2. Provider must not silently convert timezone to local time.
3. Provider must expose symbol/timeframe normalization in logs/metadata for debugging.


### 8.1. IntrabarDataProvider contract

```python
class IntrabarDataProvider(Protocol):
    def get_intrabar_bars(
        self,
        symbol: str,
        chart_bar: Bar,
        lower_timeframe: str | None = None,
        *,
        max_bars: int | None = None,
    ) -> list[Bar]: ...
```

Rules:

1. Returned intrabar bars must be inside the chart bar interval.
2. Returned bars follow the same Bar validation as chart bars.
3. If `use_bar_magnifier=True` and provider is missing/empty:
   - strict mode raises `PL_MISSING_INTRABAR_DATA`;
   - non-strict mode emits `PL_WARNING_BAR_MAGNIFIER_FALLBACK` and uses OHLC path.
4. Broker fills must record whether they used `fill_source="intrabar"` or `fill_source="ohlc_path"`.

---

## 9. StrategyContext contract

```python
class StrategyContext(Protocol):
    equity: float
    position_size: float
    position_avg_price: float
    initial_capital: float
    currency: str
    pyramiding: int
    default_qty_type: str
    default_qty_value: float
    process_orders_on_close: bool
    calc_on_order_fills: bool
    calc_on_every_tick: bool
    use_bar_magnifier: bool

    def entry(self, id: str, direction: str, qty=None, limit=None, stop=None, *, source_map=None): ...
    def exit(self, id: str, from_entry=None, qty=None, qty_percent=None, limit=None, stop=None,
             profit=None, loss=None, trail_price=None, trail_points=None, trail_offset=None,
             *, source_map=None): ...
    def order(self, id: str, direction: str, qty=None, limit=None, stop=None,
              oca_name=None, oca_type=None, *, source_map=None): ...
    def close(self, id: str, qty=None, qty_percent=None, immediately=False, *, source_map=None): ...
    def close_all(self, immediately=False, *, source_map=None): ...
    def cancel(self, id: str, *, source_map=None): ...
    def cancel_all(self, *, source_map=None): ...
```

### 9.1. Broker OHLC path

Without bar magnifier:

```python
if abs(open - high) < abs(open - low):
    path = [open, high, low, close]
else:
    path = [open, low, high, close]
```

No gap exists inside a bar. If a price order is crossed only in the gap between previous close and current open, fill at current open.

### 9.2. `strategy.exit` OCA/reservation

1. Limit/stop from the same `strategy.exit` are one bracket: first triggered fills, the other cancels.
2. `strategy.exit` orders are OCA reduce by default.
3. Multiple exits reserve position quantity in source-code call order.
4. `qty` overrides `qty_percent`.
5. Oversized exits are reduced to available position and must emit diagnostic.


### 9.3. Strategy declaration settings contract

Runtime/StrategyContext must preserve every strategy setting passed by AST2Python.

Required fields:

```text
initial_capital, currency, default_qty_type, default_qty_value, pyramiding,
commission_type, commission_value, slippage, process_orders_on_close,
calc_on_order_fills, calc_on_every_tick, use_bar_magnifier,
backtest_fill_limits_assumption, close_entries_rule, margin_long, margin_short,
max_bars_back, max_lines_count, max_labels_count, max_boxes_count
```

Unsupported parity-affecting settings must not be silently ignored.

### 9.4. Strategy execution and recalculation contract

Canonical historical strategy schedule:

```python
runtime.begin_bar(bar)
runtime.update_barstate(bar)
generated_strategy._process_bar(runtime)
runtime.strategy.accept_orders_from_generated_code()
runtime.strategy.process_orders_for_bar(runtime=runtime, bar=bar)

while runtime.strategy.has_fill_recalc_pending() and runtime.config.calc_on_order_fills:
    runtime.guard_recalc_count(runtime.config.max_recalculations_per_bar)
    runtime.strategy.update_position_equity_trades_after_fill()
    generated_strategy._process_bar(runtime)
    runtime.strategy.accept_orders_from_generated_code()
    runtime.strategy.process_orders_for_bar(runtime=runtime, bar=bar, recalc_phase=True)

runtime.end_bar()
```

Rules:

1. Generated code creates/cancels/modifies orders but never fills them.
2. Generated code never writes `position_size`, `position_avg_price`, `equity`, `opentrades`, `closedtrades` directly.
3. Runtime updates strategy fields immediately after fill and before recalculation pass.
4. `commit_current()` happens only in `runtime.end_bar()` after all recalculation phases.
5. If `calc_on_every_tick=True` but no realtime/tick data exists, runtime emits `PL_WARNING_CALC_ON_EVERY_TICK_FALLBACK`.
6. If `process_orders_on_close=True`, broker may fill eligible orders on the current bar close according to test fixtures.
7. If `use_bar_magnifier=True`, broker uses `IntrabarDataProvider`; otherwise it uses the OHLC path from section 9.1.

---

## 10. `pine_range` contract

```python
def pine_range(start: int, end: int, step: int | None = None):
    if step is None:
        step = 1 if end >= start else -1
    if step == 0:
        raise PineRuntimeError("Pine for-loop step cannot be zero")
    stop = end + (1 if step > 0 else -1)
    return range(int(start), int(stop), int(step))
```

AST2Python must use this function for Pine `for ... to ...`.

---

## 11. Diagnostics codes

| Code | Owner | Severity | Meaning |
|---|---|---|---|
| `PL_UNSUPPORTED_NESTED_SECURITY` | PineLib | error | Nested `request.*` not supported by runtime config |
| `P2A_WARNING_NESTED_SECURITY` | AST2Python | warning/error in strict | Nested `request.*` detected |
| `PL_WARNING_EXIT_QTY_REDUCED` | PineLib | warning | Exit order size reduced to reserved/available position |
| `P2A_MISSING_LOC_STATE_ID_HASH` | AST2Python | warning | `state_id` generated from AST hash because loc missing |
| `PL_DATA_FORMAT_ERROR` | PineLib | error | Invalid bars schema/order/OHLC |
| `P2A_CONTRACT_VERSION_MISMATCH` | AST2Python/generated | error | Generated code and runtime contract differ |
| `PL_UNSUPPORTED_STRATEGY_SETTING` | PineLib | error/warning | Strategy setting affects parity but is not implemented |
| `PL_MISSING_INTRABAR_DATA` | PineLib | error | Bar Magnifier requested but intrabar data unavailable |
| `PL_WARNING_BAR_MAGNIFIER_FALLBACK` | PineLib | warning | Fallback from Bar Magnifier to synthetic OHLC path |
| `PL_WARNING_CALC_ON_EVERY_TICK_FALLBACK` | PineLib | warning | `calc_on_every_tick` unavailable in historical MVP |
| `PL_INPUT_VALIDATION_ERROR` | PineLib | error | Runtime params violate input metadata |
| `PL_SESSION_PARSE_ERROR` | PineLib | error | Session/timezone parse or evaluation failed |
| `PL_REFERENCE_HISTORY_UNSUPPORTED` | PineLib | error/warning | Reference type history semantics unsupported |
| `P2A_UNSUPPORTED_DECLARATION_ARG` | AST2Python | error/warning | Declaration arg cannot be safely mapped |
| `P2A_UNKNOWN_OVERLOAD` | AST2Python | error/warning | Builtin overload cannot be resolved |
| `P2A_VISUAL_OBJECT_USED_AS_VALUE` | AST2Python | error | Visual object id used as arithmetic/bool value |

---

## 12. Generated code minimum header

```python
# Generated by AST2Python
# Pine runtime contract: 1.4
# Source: strategy.pine

REQUIRED_RUNTIME_CONTRACT = "1.4"

class GeneratedStrategy:
    def __init__(self, params=None, runtime=None):
        self.rt = runtime or PineRuntime(...)
        if self.rt.contract_version != REQUIRED_RUNTIME_CONTRACT:
            raise RuntimeContractError(
                f"Requires runtime contract {REQUIRED_RUNTIME_CONTRACT}, got {self.rt.contract_version}"
            )
```

---

## 13. Minimal compatibility test

```python
def test_runtime_contract_smoke(provider):
    bars = provider.get_bars("BINANCE:AVAXUSDT.P", "60", start=None, end=None)
    rt = PineRuntime(symbol_info=SymbolInfo(tickerid="BINANCE:AVAXUSDT.P"), timeframe="60", data_provider=provider)
    strategy = GeneratedStrategy(params={}, runtime=rt)
    result = strategy.run(bars[:500])
    assert rt.contract_version == "1.4"
    assert len(result) == 500
```


### 13.1. Required compatibility tests v1.4

In addition to the smoke test, the contract requires fixtures for:

1. `strategy()` settings mapping: commission, slippage, pyramiding, sizing, process-on-close.
2. `calc_on_order_fills=True` with at least one fill-triggered recalculation.
3. `use_bar_magnifier=True` with intrabar TP/SL ordering different from synthetic OHLC path.
4. `time()`/`time_close()` with regular session, overnight session and DST week.
5. `input.*` validation: min/max/options/session/source.
6. Reference object identity for `array`, `UDT`, `var array`, explicit copy.
7. Visual object id lifecycle: create, set, delete, var storage.
