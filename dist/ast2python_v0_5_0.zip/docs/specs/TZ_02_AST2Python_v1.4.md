# Техническое задание №2 — AST2Python

**Версия ТЗ:** 1.4 consolidated + execution/session/type-contract patch  
**Дата:** 2026-04-27  
**Проект:** AST2Python  
**Связанные проекты:** Pine2AST, PineLib/PainLib Runtime, bar-by-bar backtest engine, optimizer  
**Главная цель:** транслировать AST, полученный из Pine2AST, в исполняемый Python-код, который использует PineLib и воспроизводит Pine Script™ v6 логику 1:1.


---

## 0. Изменения v1.4 по замечаниям для 1:1 TradingView

Эта версия синхронизирована с PineLib v1.4 и `runtime_contract.md`. Нормативный приоритет:

1. `runtime_contract.md` — единый интерфейс PineLib ↔ AST2Python.
2. Это ТЗ — правила генерации Python-кода и diagnostics.
3. PineLib ТЗ — runtime-поведение, TA/request/strategy implementation.

Принятые обязательные решения:

| ID | Решение | Приоритет | Причина для 1:1 |
|---|---|---:|---|
| A-001 | Все stateful Pine-вызовы получают стабильный `state_id = L{line}_C{col}_{func}_{ordinal}` | P0 | повторная генерация должна сохранять состояние индикаторов |
| A-002 | `request.security` генерируется как callable `lambda request_rt: ...`, а не заранее вычисленное значение | P0 | expression обязан исполняться в requested context |
| A-003 | Для `set_current()` отвечает сгенерированный код, за `commit_current()` отвечает runtime | P0 | history semantics должны быть едиными |
| A-004 | Multi-return функции возвращают Python tuple; discard получает `_discard_N` | P1 | `ta.macd`, `ta.bb`, `ta.dmi`, `ta.supertrend` должны раскладываться без потери source map |
| A-005 | Для `for ... to ...` генерируется `pine_range(start, end, step)` | P2 | Pine end включительный, Python `range` — нет |
| A-006 | Nested security на MVP диагностируется как `P2A_WARNING_NESTED_SECURITY` или compile error при strict mode | P2 | не допустить silent divergence |
| A-007 | Все `strategy.*` и крупные блоки получают комментарий `# pine:Lx` и запись в sourcemap | P2 | ускоряет отладку 1:1 расхождений |
| A-008 | Генератор обязан сохранять полный mapping `strategy()`/`indicator()` declaration args в metadata и StrategyContext | P0 | неизвестные strategy properties нельзя silently ignore |
| A-009 | Добавлен Type/Qualifier resolver: `const/input/simple/series`, overload validation, bool-v6 restrictions | P0 | неверный qualifier даёт неверный Python-код ещё до runtime |
| A-010 | Добавлены правила генерации для `time()`, `time_close()`, session/timezone args | P0 | time/session фильтры часто участвуют в условиях входа/выхода |
| A-011 | Visual functions для `label/line/box/table` генерируются через recorder с object IDs | P1 | `var line/label` должен сохранять id и не ломать код |
| A-012 | Input metadata расширена до min/max/step/options/group/inline/tooltip/display/active | P1 | optimizer должен видеть те же параметры, что Pine input UI |
| A-013 | Reference types `array/map/matrix/UDT` получают явную copy/reference/history semantics | P1 | pivot/zigzag и custom structures иначе расходятся |
| A-014 | Добавлен generated phase contract: generated code создаёт orders, но не исполняет fills | P0 | broker/recalc schedule должен оставаться в runtime |


### 0.1. Дополнения v1.4

Версия v1.4 наследует все решения v1.3 и добавляет требования к генерации declaration mapping, TypeInfo/qualifier validation, time/session calls, visual object recorder, расширенному input metadata и strategy phase ownership.


## 1. Назначение и границы проекта

AST2Python — кодогенератор. Он не должен реализовывать математику индикаторов и не должен сам эмулировать сделки. Эти задачи относятся к PineLib. AST2Python отвечает за корректное преобразование Pine AST в Python-класс/модуль с сохранением:

- порядка исполнения;
- областей видимости;
- series/history semantics;
- `var`/`varip` semantics;
- input/default параметров;
- вызовов `ta.*`, `math.*`, `request.*`, `strategy.*`;
- source map для диагностики;
- читаемости сгенерированного кода.

---

## 2. Входы и выходы

### 2.1. Вход

AST от Pine2AST в стабильном JSON/dataclass формате.

Минимальные поля AST-узла:

```json
{
  "type": "CallExpression",
  "loc": {
    "start": {"line": 10, "column": 4},
    "end": {"line": 10, "column": 28}
  },
  "source": "ta.ema(close, 200)",
  "children": []
}
```

### 2.2. Выход

Python-модуль:

```text
generated/
  strategy_name.py
  strategy_name.meta.json
  strategy_name.coverage.json
```

### 2.3. Требования к выходному коду

1. Код должен быть форматированным и читаемым.
2. Код должен запускаться без eval/exec в runtime.
3. Все импорты должны быть явными.
4. Все unsupported-узлы должны падать во время генерации, а не во время backtest.
5. Должен сохраняться source map: Python line -> Pine source line.
6. Сгенерированный класс должен иметь единый интерфейс для движка:

```python
strategy = GeneratedStrategy(params=params, runtime=runtime)
result = strategy.run(bars)
```

---

## 3. Архитектура пакета

```text
ast2python/
  __init__.py
  version.py
  errors.py

  translator.py
  context.py
  naming.py
  source_map.py
  coverage.py
  diagnostics.py
  config.py

  ast/
    __init__.py
    schema.py
    validators.py
    visitors.py

  generators/
    __init__.py
    program.py
    declarations.py
    variables.py
    expressions.py
    statements.py
    functions.py
    types.py
    strategy.py
    request.py
    visual.py
    inputs.py
    filters.py

  emitters/
    __init__.py
    code_emitter.py
    imports.py
    comments.py
    templates.py

  templates/
    module.py.j2
    strategy.py.j2
    indicator.py.j2
    library.py.j2
    function.py.j2

  runtime_contract/
    __init__.py
    generated_base.py
    interfaces.py

  cli/
    __init__.py
    main.py

tests/
  unit/
  fixtures/
    ast/
    expected/
  integration/
```

---

## 4. Главные проектные решения

### 4.1. Генерировать класс, а не плоский скрипт

Для стратегии:

```python
class MyStrategy(GeneratedStrategyBase):
    ...
```

Для индикатора:

```python
class MyIndicator(GeneratedIndicatorBase):
    ...
```

Причина: Pine исполняется много раз на барах, а состояние должно жить между вызовами `_process_bar`.

### 4.2. Runtime внедряется через dependency injection

```python
def __init__(self, params=None, runtime=None):
    self.runtime = runtime or PineRuntime(...)
    self.ctx = StrategyContext(...)
```

### 4.3. Все Pine built-ins идут через PineLib

Примеры:

```text
ta.ema              -> self.rt.ta.ema(...)
math.round          -> pine_round(...)
request.security    -> self.rt.request.security(...)
strategy.entry      -> self.ctx.entry(...)
close               -> self.close.current или self.close
close[1]            -> self.close[1]
```

Финальная форма зависит от выбранной модели Series в PineLib. В ТЗ фиксируется требование: AST2Python не должен самостоятельно считать EMA/RSI/ATR.

### 4.4. Source map и читаемые Pine-комментарии обязательны

Каждый крупный блок должен содержать комментарий:

```python
# pine:L12 filters: allowLong = needLong and ...
self.allow_long.set_current(...)
```

Для всех `strategy.*`, `request.*`, tuple declarations, UDF declarations и switch-блоков комментарий обязателен даже в non-debug режиме.

Пример:

```python
# pine:L130 strategy.exit("TP1 Long", "Long", profit = atr * tpMult, qty_percent=35)
self.ctx.exit(
    id="TP1 Long",
    from_entry="Long",
    profit=self.atr.current * self.tp_mult.current,
    qty_percent=35,
    source_map="L130"
)
```

В `.meta.json` сохранить:

```json
{
  "python_line": 120,
  "pine_line": 45,
  "pine_source": "strategy.entry(\"Long\", strategy.long)"
}
```

---

## 5. TranslationContext

```python
@dataclass
class VariableInfo:
    pine_name: str
    py_name: str
    type_ref: str | None
    qualifier: str | None
    declaration_kind: str  # normal, var, varip, input, const
    is_series: bool
    is_mutable: bool
    scope_id: str
    first_decl_loc: SourceLocation | None = None

@dataclass
class Scope:
    id: str
    kind: str  # global, function, block, loop, switch, method
    parent_id: str | None
    variables: dict[str, VariableInfo]

@dataclass
class TranslationContext:
    variables: dict[str, VariableInfo]
    scopes: list[Scope]
    imports: ImportManager
    source_map: SourceMapBuilder
    diagnostics: list[Diagnostic]
    coverage: CoverageTracker
    indent_level: int = 0
    current_function: str | None = None
    current_class: str | None = None
    mode: str = "strategy"  # strategy, indicator, library
```

### 5.1. Методы контекста

```python
def enter_scope(kind: str) -> Scope: ...
def exit_scope() -> None: ...
def declare_var(name, type_ref, qualifier, kind, loc) -> VariableInfo: ...
def resolve_var(name) -> VariableInfo: ...
def require_import(symbol) -> None: ...
def emit(code: str, loc=None) -> None: ...
def unsupported(node, reason) -> NoReturn: ...
```

---

## 6. ImportManager

### 6.1. Требование

Импорты добавляются только если реально использованы.

### 6.2. Пример

Pine:

```pinescript
atr = ta.atr(14)
r = math.round(atr)
```

Python:

```python
from pinelib.ta import atr
from pinelib.math import pine_round
```

### 6.3. Конфликтные имена

| Pine | Python import |
|---|---|
| `math.abs` | `pine_abs` |
| `math.round` | `pine_round` |
| `math.min` | `pine_min` |
| `math.max` | `pine_max` |
| `math.sum` | `pine_sum` |
| `input` | `pine_input` |
| `str` | `pine_str` |

---

## 7. Naming rules

### 7.1. Общие правила

```text
camelCase -> snake_case
PascalCase -> pascal_case или class PascalCase
effMinBodyATR -> eff_min_body_atr
XLMMode -> xlm_mode
```

### 7.2. Зарезервированные слова Python

Если имя конфликтует с Python keyword/builtin:

```text
from -> from_
class -> class_
lambda -> lambda_
input -> input_
str -> str_
```

### 7.3. Стабильность имён

Имя должно быть детерминированным: один и тот же AST всегда даёт один и тот же Python-код.

### 7.4. `_` в tuple declarations

Pine:

```pinescript
[macdLine, signalLine, _] = ta.macd(close, 12, 26, 9)
```

Python:

```python
_macd_line, _signal_line, _discard_1 = macd(...)
```

Нельзя переиспользовать `_`, если это мешает source map/diagnostics.

Правило для множественных discard:

```python
_discard_1, _discard_2, ...
```

Счётчик discard сбрасывается на границе функции/метода/класса, но не внутри одного tuple declaration.

---

## 8. Модель сгенерированного модуля

```python
#!/usr/bin/env python3
"""
Generated by AST2Python 1.4
Source: strategy.pine
Pine version: 6
"""

from __future__ import annotations

from pinelib.core import PineRuntime, Series, na, is_na, nz
from pinelib.strategy import StrategyContext
# auto imports...

class Grok65StableForced:
    """
    Generated from:
    strategy("Grok 6.5 Stable Forced", overlay=true, ...)
    """

    def __init__(self, params=None, runtime=None):
        self.params = params or {}
        self.rt = runtime or PineRuntime(...)
        self.ctx = StrategyContext(...)
        self._init_inputs()
        self._init_series()
        self._init_var_state()

    def run(self, bars):
        results = []
        for index, bar in enumerate(bars):
            self.rt.begin_bar(bar)
            self._process_bar(bar, index)
            self.rt.end_bar()
            results.append(self._snapshot())
        return results

    def _process_bar(self, bar, index):
        self._load_builtin_series(bar, index)
        self._execute_user_code()

    def _snapshot(self):
        return {
            "bar_index": self.bar_index,
            "position_size": self.ctx.position_size,
            ...
        }
```

---

## 9. Трансляция Program/declaration

### 9.1. `//@version=6`

Проверить, что версия поддерживается. Если версия ниже 6:

- либо включить compatibility mode;
- либо остановить генерацию с понятной ошибкой.

MVP: поддерживать только v6.

### 9.2. `strategy(...)`

Pine:

```pinescript
strategy("My Strategy", overlay=true, commission_type=strategy.commission.percent, commission_value=0.055)
```

Python:

```python
self.ctx = StrategyContext(
    commission_type="percent",
    commission_value=0.055,
    overlay=True,
)
```

Сохранить все параметры declaration в `meta.json`.

### 9.3. `indicator(...)`

Генерировать `GeneratedIndicatorBase`, без `StrategyContext`, но с visual recorder.

### 9.4. `library(...)`

Генерировать набор Python-функций/класс библиотеки.

---

## 10. Built-in series

### 10.1. OHLCV

```text
open    -> self.open
high    -> self.high
low     -> self.low
close   -> self.close
volume  -> self.volume
hl2     -> (self.high + self.low) / 2
hlc3    -> (self.high + self.low + self.close) / 3
ohlc4   -> (self.open + self.high + self.low + self.close) / 4
hlcc4   -> (self.high + self.low + self.close + self.close) / 4
```

В зависимости от PineLib `Series` API:

```python
self.close.set_current(bar.close)
# или
self.close = self.rt.series("close", "float")
self.close.current == bar.close
```

### 10.2. Time

```text
time
time_close
timenow
year
month
weekofyear
dayofmonth
dayofweek
hour
minute
second
```

MVP: `time`, `time_close`. Остальные через PineLib time helpers.

### 10.3. bar_index

```python
self.bar_index = index
```

---

## 11. Var declarations

### 11.1. Normal declaration

Pine:

```pinescript
float effMinBodyATR = minBodyATR
```

Python:

```python
# pine: float effMinBodyATR = minBodyATR
self.eff_min_body_atr.set_current(self.min_body_atr.current)
```

Если выбрана простая модель attributes, допускается:

```python
self.eff_min_body_atr = self.min_body_atr
```

Но для history reference переменной она должна быть Series.

### 11.2. `var`

Pine:

```pinescript
var int addCount = 0
```

Python:

```python
if not self.rt.has_var("add_count"):
    self.rt.init_var("add_count", 0, dtype="int")
self.add_count.set_current(self.rt.get_var("add_count"))
```

В конце бара значение должно сохраняться.

### 11.3. `varip`

Pine:

```pinescript
varip float intrabarHigh = na
```

Python:

```python
self.rt.init_varip("intrabar_high", na, dtype="float")
```

MVP historical mode: как `var`, но с отдельным API.

### 11.4. Reassignment `:=`

Pine:

```pinescript
x := x + 1
```

Python:

```python
self.x.set_current(self.x.current + 1)
```

---

## 12. Tuple declarations

Pine:

```pinescript
[basis, upper, lower] = ta.bb(close, 20, 2)
[macdLine, signalLine, _] = ta.macd(close, 12, 26, 9)
```

Python:

```python
_basis, _upper, _lower = bb(self.close, 20, 2, runtime=self.rt, state_id="bb_1")
self.basis.set_current(_basis)
self.upper.set_current(_upper)
self.lower.set_current(_lower)

_macd_line, _signal_line, _discard_1 = macd(self.close, 12, 26, 9, runtime=self.rt, state_id="macd_1")
self.macd_line.set_current(_macd_line)
self.signal_line.set_current(_signal_line)
```

### 12.1. Multi-return functions

Если Pine-функция возвращает несколько значений, Python генерирует обычный tuple.

Pine:

```pinescript
[macdLine, signalLine, _] = ta.macd(close, 12, 26, 9)
[basis, upper, lower] = ta.bb(close, 20, 2)
```

Python:

```python
_macd_line, _signal_line, _discard_1 = macd(
    self.close, 12, 26, 9, runtime=self.rt, state_id="L10_C26_macd_1"
)
self.macd_line.set_current(_macd_line)
self.signal_line.set_current(_signal_line)

_basis, _upper, _lower = bb(
    self.close, 20, 2, runtime=self.rt, state_id="L11_C25_bb_1"
)
self.basis.set_current(_basis)
self.upper.set_current(_upper)
self.lower.set_current(_lower)
```

Если tuple-значение присваивается series-переменной, каждое значение проходит через отдельный `set_current()`. Если значение локальное внутри функции и не является series, допускается обычная локальная переменная.

---

## 13. Expressions

### 13.1. Literals

```text
1       -> 1
1.5     -> 1.5
true    -> True
false   -> False
na      -> na
"abc"   -> "abc"
```

### 13.2. Binary operators

| Pine | Python |
|---|---|
| `+` | `pine_add(a, b)` или `a + b` если safe |
| `-` | `pine_sub(a, b)` |
| `*` | `pine_mul(a, b)` |
| `/` | `pine_div(a, b)` |
| `%` | `pine_mod(a, b)` |
| `==` | `pine_eq(a, b)` |
| `!=` | `pine_ne(a, b)` |
| `<` | `pine_lt(a, b)` |
| `>` | `pine_gt(a, b)` |
| `<=` | `pine_lte(a, b)` |
| `>=` | `pine_gte(a, b)` |
| `and` | Python `and` с safe bool conversion |
| `or` | Python `or` с safe bool conversion |

MVP может использовать обычные Python-операторы только там, где типы гарантированно безопасны.

### 13.3. Unary operators

```text
-not x -> not pine_bool(x)
-x     -> pine_neg(x)
+x     -> pine_pos(x)
```

### 13.4. Ternary

Pine:

```pinescript
x = cond ? a : b
```

Python:

```python
self.x.set_current(a if pine_bool(cond) else b)
```

### 13.5. Nested ternary

Должен форматироваться читаемо:

```python
value = (
    a if cond1 else
    b if cond2 else
    c
)
```

### 13.6. History reference

Pine:

```pinescript
close[1]
ta.sma(close, 10)[1]
(myObject[10]).field
```

Python:

```python
self.close[1]
self.rt.history(sma(...), 1)
self.my_object[10].field
```

**Важно:** Pine v6 запрещает history reference на литералах/константах и прямой `object.field[10]` для UDT-поля. AST2Python должен валидировать это до генерации.

---


## 13A. Type/Qualifier resolver

AST2Python обязан до генерации кода построить `TypeInfo` для expression/variable/call nodes.

```python
@dataclass
class TypeInfo:
    base_type: str              # int/float/bool/string/color/array/matrix/map/UDT/object
    qualifier: str              # const/input/simple/series
    is_reference_type: bool
    can_be_na: bool
    is_history_allowed: bool
    pine_type_source: str | None = None
```

Qualifier lattice:

```text
const < input < simple < series
```

Rules:

1. Если builtin overload требует `simple int`, а выражение имеет `series int`, генерация должна падать compile error.
2. Если expression может быть `na`, а целевой тип `bool`, генерация должна падать или явно привести через Pine-compatible helper, если это разрешено Pine v6.
3. `na(x)`, `nz(x)`, `fixnan(x)` для bool запрещены на этапе генерации.
4. `input.*` declarations получают qualifier `input`, но при присвоении в series-переменную становятся текущим value в Series.
5. `const` expressions могут быть folded только если это не меняет source map и diagnostics.
6. Любой call без известного overload получает diagnostic `P2A_UNKNOWN_OVERLOAD` и в strict mode — compile error.
7. TypeInfo сохраняется в `.meta.json` для debug/optimizer режима.

Reference type rules для генератора:

1. `array/map/matrix/UDT` не должны неявно deep-copy при assignment.
2. `array.copy/map.copy/matrix.copy` генерируются как явные runtime calls.
3. History reference для `arrayVar[1]`, `myObj[1]`, `(myObj[10]).field` генерируется только если runtime contract поддерживает соответствующий mode.
4. Прямой `myObj.field[10]`, запрещённый Pine v6 для UDT-поля, должен падать до генерации.

---

## 14. Member access и calls

### 14.1. Namespaces

| Pine | Python |
|---|---|
| `ta.ema` | `ema` или `self.rt.ta.ema` |
| `math.round` | `pine_round` |
| `request.security` | `self.rt.request.security` |
| `strategy.entry` | `self.ctx.entry` |
| `syminfo.tickerid` | `self.rt.syminfo.tickerid` |
| `timeframe.period` | `self.rt.timeframe.period` |
| `barstate.isfirst` | `self.rt.barstate.isfirst` |
| `array.push` | `pine_array.push` |
| `str.tostring` | `pine_str.tostring` |
| `color.new` | `pine_color.new` |

### 14.2. Function call state_id

Все stateful TA/request calls должны получать стабильный `state_id`.

Нормативный формат:

```python
state_id = f"L{line}_C{col_start}_{func_name}_{ordinal}"
```

Где:

- `line` и `col_start` — координаты начала AST call node из Pine source.
- `func_name` — нормализованное имя функции без namespace: `ema`, `rma`, `security`, `supertrend`.
- `ordinal` — порядковый номер call node на той же позиции, если Pine2AST даёт одинаковые loc для вложенных/сгенерированных узлов. Обычно `1`.

Примеры:

```pinescript
emaFast = ta.ema(close, 12)
emaSlow = ta.ema(close, 26)
```

```python
self.ema_fast.set_current(ema(self.close, 12, runtime=self.rt, state_id="L10_C12_ema_1"))
self.ema_slow.set_current(ema(self.close, 26, runtime=self.rt, state_id="L11_C12_ema_1"))
```

Fallback, если `loc` отсутствует: `state_id = "N" + stable_hash(ast_node_id + normalized_source)[:16]`. Повторный прогон того же AST обязан давать те же `state_id`.

Без стабильного `state_id` две EMA с разными length могут смешать состояние.


### 14.3. Time/session calls

AST2Python должен различать built-in series `time/time_close` и function calls `time(...)` / `time_close(...)`.

| Pine | Python generation |
|---|---|
| `time` | `self.rt.time` или `self.time` |
| `time_close` | `self.rt.time_close` или `self.time_close` |
| `time("D")` | `self.rt.timefunc.time("D", runtime=self.rt, source_map="Lx")` |
| `time(timeframe.period, sessionInput)` | `self.rt.timefunc.time(self.rt.timeframe.period, self.session_input.current, runtime=self.rt, source_map="Lx")` |
| `time_close("60", "0900-1700")` | `self.rt.timefunc.time_close("60", "0900-1700", runtime=self.rt, source_map="Lx")` |

Rules:

1. Session/timezone arguments must not be evaluated using local machine timezone.
2. If session argument is `input.session`, generated code passes current input value to runtime helper.
3. Date helpers `year/month/weekofyear/dayofweek/hour/minute/second` must call PineLib time helpers, not Python `datetime` directly.
4. If runtime lacks session contract version 1.4, generated code must fail with `P2A_CONTRACT_VERSION_MISMATCH`.

---

## 15. Statements

### 15.1. If

Pine:

```pinescript
if longEntry and tradeDateIsAllowed
    strategy.entry("Long", strategy.long)
else
    strategy.cancel("Long")
```

Python:

```python
if pine_bool(self.long_entry.current) and pine_bool(self.trade_date_is_allowed.current):
    self.ctx.entry("Long", "long")
else:
    self.ctx.cancel("Long")
```

### 15.2. Switch

Pine:

```pinescript
switch ticker
    "AVAXUSDT.P" =>
        effMinBodyATR := 0.11
    "SOLUSDT.P" =>
        effMinBodyATR := 0.13
```

Python:

```python
if self.ticker.current == "AVAXUSDT.P":
    self.eff_min_body_atr.set_current(0.11)
elif self.ticker.current == "SOLUSDT.P":
    self.eff_min_body_atr.set_current(0.13)
```

Expression-switch:

```pinescript
x = switch
    cond1 => a
    cond2 => b
    => c
```

Python:

```python
if pine_bool(cond1):
    _switch_value = a
elif pine_bool(cond2):
    _switch_value = b
else:
    _switch_value = c
self.x.set_current(_switch_value)
```

### 15.3. For

Pine:

```pinescript
for i = 0 to len - 1
    sum += array.get(arr, i)
```

Python:

```python
for i in pine_range(0, self.len.current - 1):
    self.sum.set_current(self.sum.current + arr.get(i))
```

`pine_range` должен учитывать inclusive end Pine-семантики.

### 15.4. While

Проверять max-iterations guard, чтобы сгенерированный код не зависал.

```python
_guard = 0
while pine_bool(cond):
    ...
    _guard += 1
    if _guard > self.rt.config.max_loop_iterations:
        raise PineRuntimeError(...)
```

### 15.5. Break/continue

Транслировать напрямую, но учитывать scope.

---

## 16. Functions and methods

### 16.1. Function declaration

Pine:

```pinescript
f_zz(_src, _length, _detection) =>
    len1 = effXlmMode ? _length + 1 : _length
    ...
```

Python:

```python
def f_zz(self, _src, _length, _detection):
    len1 = _length + 1 if pine_bool(self.eff_xlm_mode.current) else _length
    ...
    return _zigzag
```

### 16.2. Multi-statement function

Последнее выражение Pine-функции становится `return`.

### 16.3. Local scopes

Локальные переменные внутри функции не должны конфликтовать с series-полями класса.

### 16.4. Methods

Pine:

```pinescript
method myMethod(MyType this, int x) =>
    ...
```

Python:

```python
def my_method(self, this, x):
    ...
```

---

## 17. UDT и enum

### 17.1. UDT

Pine:

```pinescript
type Pivot
    float price
    int index
```

Python:

```python
@dataclass
class Pivot:
    price: float = na
    index: int = 0
```

### 17.2. UDT history

Pine v6:

```pinescript
(myObject[10]).field
```

Python:

```python
self.my_object[10].field
```

AST2Python должен не генерировать `self.my_object.field[10]`.

### 17.3. Enum

Pine:

```pinescript
enum Direction
    long
    short
```

Python:

```python
class Direction(Enum):
    LONG = "long"
    SHORT = "short"
```

---

## 18. request.security generation

Pine:

```pinescript
dailyEma200 = request.security(syminfo.tickerid, "D", ta.ema(close, 200), lookahead=barmerge.lookahead_on)
```

Python:

```python
self.daily_ema200.set_current(
    self.rt.request.security(
        self.rt.syminfo.tickerid,
        "D",
        lambda request_rt: ema(
            request_rt.close,
            200,
            runtime=request_rt,
            state_id="L42_C51_ema_1"
        ),
        lookahead="barmerge.lookahead_on",
        gaps="barmerge.gaps_off",
        runtime=self.rt,
        state_id="L42_C15_security_1",
        source_map="L42"
    )
)
```

### 18.1. Важное требование

`expression` генерировать только как lambda/callable с аргументом `request_rt`, а не как заранее вычисленное значение. Иначе выражение будет посчитано на текущем timeframe, а не внутри контекста requested timeframe.

Запрещено:

```python
# Неверно: ema уже вычислена на chart timeframe
security(symbol, "D", ema(self.close, 200, runtime=self.rt, state_id="..."))
```

Обязательно:

```python
security(
    symbol,
    "D",
    lambda request_rt: ema(request_rt.close, 200, runtime=request_rt, state_id="L42_C51_ema_1"),
    runtime=self.rt,
    state_id="L42_C15_security_1",
)
```

### 18.2. Captures

Если expression использует переменные внешнего scope, AST2Python должен явно определить, что безопасно захватывать, а что должно быть пересчитано в request-context.

### 18.3. Dynamic requests

В Pine v6 request может быть в if/loop/function. AST2Python не должен выносить все security-вызовы наверх без анализа зависимостей.

### 18.4. Nested requests diagnostic

Если внутри `request.security(..., expression)` обнаружен другой `request.*` call:

- default mode: сгенерировать warning `P2A_WARNING_NESTED_SECURITY` и оставить вызов только если PineLib feature flag `supports_nested_security=True`;
- strict mode: остановить генерацию с `PineUnsupportedNodeError(code="P2A_UNSUPPORTED_NESTED_SECURITY")`;
- runtime mode без поддержки: PineLib выбрасывает `PL_UNSUPPORTED_NESTED_SECURITY`.

Сообщение:

```text
P2A_WARNING_NESTED_SECURITY: request.security inside request.security expression may not be supported by PineLib MVP
```

---

## 19. Strategy generation

### 19.1. `strategy.entry`

Pine:

```pinescript
strategy.entry("Long", strategy.long, qty=lot, stop=uplevel)
```

Python:

```python
self.ctx.entry(
    id="Long",
    direction="long",
    qty=self.lot.current,
    stop=self.uplevel.current,
    source_map="L120"
)
```

### 19.2. `strategy.exit`

Pine:

```pinescript
strategy.exit("TP1 Long", "Long", profit=atr * tpMult, qty_percent=35)
```

Python:

```python
self.ctx.exit(
    id="TP1 Long",
    from_entry="Long",
    profit=self.atr.current * self.tp_mult.current,
    qty_percent=35,
    source_map="L130"
)
```

### 19.3. `strategy.close`

```python
self.ctx.close(id="Long", comment=..., immediately=...)
```

### 19.4. Strategy constants

```text
strategy.long                    -> "long"
strategy.short                   -> "short"
strategy.percent_of_equity       -> "percent_of_equity"
strategy.cash                    -> "cash"
strategy.fixed                   -> "fixed"
strategy.commission.percent      -> "percent"
strategy.commission.cash_per_order -> "cash_per_order"
strategy.oca.reduce              -> "reduce"
```


### 19.5. Полный mapping `strategy()` declaration args

AST2Python обязан сохранить все аргументы `strategy(...)` в `.meta.json` и передать runtime-relevant arguments в `StrategyContext`.

Supported mapping:

| Pine argument | Generated target | Mode |
|---|---|---|
| `initial_capital` | `StrategyContext(initial_capital=...)` | P0 |
| `currency` | `StrategyContext(currency=...)` | P0 |
| `default_qty_type` | `StrategyContext(default_qty_type=...)` | P0 |
| `default_qty_value` | `StrategyContext(default_qty_value=...)` | P0 |
| `pyramiding` | `StrategyContext(pyramiding=...)` | P0 |
| `commission_type` | `StrategyContext(commission_type=...)` | P0 |
| `commission_value` | `StrategyContext(commission_value=...)` | P0 |
| `slippage` | `StrategyContext(slippage=...)` | P0 |
| `process_orders_on_close` | `StrategyContext(process_orders_on_close=...)` | P0 |
| `calc_on_order_fills` | `StrategyContext(calc_on_order_fills=...)` | P0 |
| `calc_on_every_tick` | `StrategyContext(calc_on_every_tick=...)` + diagnostic if historical fallback | P1 |
| `use_bar_magnifier` | `StrategyContext(use_bar_magnifier=...)` | P0 |
| `backtest_fill_limits_assumption` | `StrategyContext(backtest_fill_limits_assumption=...)` | P1 |
| `close_entries_rule` | `StrategyContext(close_entries_rule=...)` | P1 |
| `margin_long` / `margin_short` | `StrategyContext(margin_long=..., margin_short=...)` | P1 |
| `max_bars_back` | runtime/history config | P0 |
| `max_lines_count` / `max_labels_count` / `max_boxes_count` | visual recorder limits | P1 |

Unknown declaration args:

- strict mode: `P2A_UNSUPPORTED_DECLARATION_ARG` compile error.
- non-strict mode: warning + сохранить в `meta.unsupported_declaration_args`.
- Аргументы, влияющие на fills/equity/sizing, нельзя просто игнорировать даже в non-strict mode; нужен warning уровня parity-risk.

### 19.6. Generated strategy phase contract

Generated code отвечает только за вычисление Pine expressions и вызовы `self.ctx.entry/exit/order/close/cancel`. Generated code не должен:

1. самостоятельно исполнять fills;
2. менять `position_size`, `position_avg_price`, `equity`, `opentrades`, `closedtrades` напрямую;
3. вызывать `runtime.end_bar()` или `commit_current()`;
4. решать, нужен ли recalculation after fill.

Generated code может читать strategy runtime fields:

```python
self.ctx.position_size
self.ctx.position_avg_price
self.ctx.equity
self.ctx.closedtrades
self.ctx.opentrades
```

Но значения этих полей определяет только `StrategyExecutionSchedule` из `runtime_contract.md`.

---

## 20. Visual functions

На MVP визуальные функции не должны ломать генерацию.

```text
plot
plotshape
plotchar
hline
fill
bgcolor
barcolor
alert
alertcondition
label.new
line.new
box.new
table.new
```

Стратегия:

1. Если visual не влияет на торговую логику — генерировать no-op recorder.
2. Если visual-вызов участвует в expression/side-effect, требуется явная диагностика.

Пример:

```python
self.rt.visual.plot(self.ema200.current, title="EMA 200", source_map="L77")
```


### 20.1. Visual object IDs и recorder generation

Для object-producing visual calls генератор должен использовать runtime recorder, а не `None`/pass.

Pine:

```pinescript
var line l = na
if barstate.isfirst
    l := line.new(bar_index, close, bar_index + 1, close)
line.set_xy1(l, bar_index, close)
```

Python:

```python
if self.rt.barstate.isfirst:
    self.l.set_current(
        self.rt.visual.line_new(self.bar_index.current, self.close.current, self.bar_index.current + 1, self.close.current, source_map="L3")
    )
self.rt.visual.line_set_xy1(self.l.current, self.bar_index.current, self.close.current, source_map="L4")
```

Rules:

1. `label.new`, `line.new`, `box.new`, `table.new` возвращают `PineObjectId`.
2. `line.set_*`, `label.set_*`, `box.set_*`, `table.cell`, `delete` генерируются как calls recorder API.
3. Если visual call result присваивается `var`/series, использовать `set_current()`.
4. Если visual object участвует в arithmetic/bool expression — compile error `P2A_VISUAL_OBJECT_USED_AS_VALUE`.
5. Visual limits из declaration передаются в runtime metadata.

---

## 21. Input generation

Pine:

```pinescript
needLong = input.bool(true, "Need Long")
emaLen = input.int(200, "EMA Length", minval=1)
```

Python:

```python
self.need_long = self.rt.series("need_long", dtype="bool")
self.need_long.set_current(self.params.get("needLong", True))

self.ema_len = self.rt.series("ema_len", dtype="int")
self.ema_len.set_current(self.params.get("emaLen", 200))
```

В `.meta.json`:

```json
{
  "inputs": [
    {
      "pine_name": "needLong",
      "py_name": "need_long",
      "type": "bool",
      "default": true,
      "title": "Need Long"
    }
  ]
}
```


### 21.1. Расширенный input metadata

AST2Python обязан сохранять не только default/title, но весь input contract, нужный runtime и optimizer.

```json
{
  "pine_name": "emaLen",
  "py_name": "ema_len",
  "type": "int",
  "qualifier": "input",
  "default": 200,
  "title": "EMA Length",
  "minval": 1,
  "maxval": 1000,
  "step": 1,
  "options": null,
  "group": "Trend",
  "inline": null,
  "tooltip": "EMA length",
  "confirm": false,
  "display": "all",
  "active": true,
  "source_map": "L12"
}
```

Generation rules:

1. Runtime params lookup должен использовать stable external key: исходное Pine имя, если нет override.
2. `input.source` должен генерировать ссылку на runtime Series, а не snapshot value.
3. `input.timeframe` сохраняет Pine notation без нормализации в минуты, если это нужно для source parity.
4. `input.session` передаётся как строка session parser runtime.
5. `input.enum` сохраняет enum type и allowed values.
6. Все validation constraints попадают в `.meta.json` и runtime init.

---

## 22. Generated metadata

### 22.1. `.meta.json`

```json
{
  "ast2python_version": "1.4",
  "pine_version": 6,
  "source_file": "strategy.pine",
  "declaration": {
    "kind": "strategy",
    "title": "Grok 6.5 Stable Forced"
  },
  "inputs": [],
  "used_builtins": [],
  "unsupported_nodes": [],
  "source_map_file": "strategy_name.sourcemap.json"
}
```

### 22.2. `.coverage.json`

```json
{
  "nodes_total": 1234,
  "nodes_generated": 1234,
  "nodes_unsupported": 0,
  "builtins": {
    "ta.ema": 12,
    "strategy.entry": 2
  }
}
```

### 22.3. `.sourcemap.json`

```json
[
  {
    "python_line": 155,
    "pine_line": 88,
    "pine_column": 4,
    "pine_source": "allowLong = needLong and ..."
  }
]
```

---

## 23. CLI

### 23.1. Команды

```bash
ast2python translate strategy.pine.ast.json -o generated/
ast2python validate strategy.pine.ast.json
ast2python coverage strategy.pine.ast.json
ast2python smoke generated/strategy.py --bars fixtures/bars.csv
```

### 23.2. Опции

```text
--mode strategy|indicator|library|auto
--pine-version 6
--strict
--allow-visual-noop
--target-runtime pinelib
--emit-source-comments
--emit-meta
--format black
```

---

## 24. Errors and diagnostics

### 24.1. Исключения

```text
AST2PythonError
UnsupportedNodeError
UnsupportedBuiltinError
TypeResolutionError
ScopeResolutionError
NameCollisionError
CodegenError
SourceMapError
```

### 24.2. Формат ошибки

```text
UnsupportedBuiltinError:
  builtin: request.financial
  pine location: line 42, column 10
  source: request.financial(...)
  reason: PineLib runtime does not implement request.financial yet
  fix: implement PineLib request.financial or exclude this feature
```

---

## 25. Тестирование AST2Python

### 25.1. Unit tests

```text
test_naming.py
test_imports.py
test_context_scope.py
test_literals.py
test_binary_expr.py
test_ternary_expr.py
test_history_reference.py
test_var_decl.py
test_tuple_decl.py
test_if.py
test_switch.py
test_for.py
test_function_decl.py
test_udt.py
test_enum.py
test_request_security_codegen.py
test_strategy_codegen.py
```

### 25.2. Snapshot tests

Для каждого AST fixture:

```text
fixtures/ast/ema_strategy.ast.json
fixtures/expected/ema_strategy.py
```

Тест:

```python
def test_translate_ema_strategy_snapshot():
    code = translate_ast(load_fixture("ema_strategy.ast.json"))
    assert_code_equal(code, load_fixture("ema_strategy.py"))
```

### 25.3. Compile tests

Каждый generated Python должен проходить:

```python
compile(code, filename, "exec")
```

### 25.4. Runtime smoke tests

Сгенерированный код должен запускаться на маленьком bars fixture:

```python
strategy = GeneratedStrategy(params={})
strategy.run(sample_bars)
```

### 25.5. Integration tests

```python
def test_avax_strategy_full_pipeline():
    ast = pine2ast("AVAX.txt")
    code = ast2python(ast)
    strategy = import_generated(code)
    result = strategy.run(bars)
    assert_trades_equal(result.trades, tv_trades)
```

---

## 26. Acceptance criteria

AST2Python считается готовым для MVP, если:

1. Поддерживает Pine2AST AST schema текущей версии.
2. Генерирует Python для целевых стратегий без unsupported-узлов.
3. Generated code проходит `compile()`.
4. Generated code проходит `ruff`/`black` или внутренний formatter.
5. Source map покрывает не менее 95% executable Pine lines.
6. Coverage report показывает 0 unsupported nodes для целевой стратегии.
7. Все input-параметры попадают в `params` contract.
8. Все stateful TA calls имеют стабильный `state_id`.
9. Все `request.security` генерируются как callable expression в request-context.
10. Все `strategy.*` вызовы идут через `StrategyContext`.
11. AVAX integration test проходит до уровня сигналов, а после готовности PineLib broker — до уровня сделок.

---

## 27. Milestones

| Этап | Содержание | Результат | Оценка |
|---|---|---|---:|
| M1 | AST schema adapter, validators, base visitor | AST читается и валидируется | 2-3 дня |
| M2 | TranslationContext, ImportManager, CodeEmitter | базовая инфраструктура | 2-3 дня |
| M3 | Program/declaration/input generation | module/class skeleton | 2-3 дня |
| M4 | Variables: normal/var/varip, assignments, tuple | корректное состояние | 3-5 дней |
| M5 | Expressions: literals, binary, unary, ternary, calls | основные expressions | 3-5 дней |
| M6 | History reference/member access/type validation | series semantics | 2-4 дня |
| M7 | Statements: if/switch/for/while/break/continue | control flow | 3-5 дней |
| M8 | Functions/methods/local scopes | пользовательские функции | 2-4 дня |
| M9 | UDT/enum | кастомные типы | 2-4 дня |
| M10 | request.security codegen | MTF генерация | 3-6 дней |
| M11 | strategy.* codegen | trade API генерация | 3-5 дней |
| M12 | visual no-op recorder | plot/label/table не ломают код | 1-3 дня |
| M13 | source map/coverage/diagnostics | debug-ready generator | 2-4 дня |
| M14 | CLI + packaging | usable tool | 1-2 дня |
| M15 | AVAX/SOL/XLM full pipeline tests | end-to-end validation | 5-10 дней |

**Итого реалистично:** 35-65 календарных дней.  
**Ускоренный вариант под одну стратегию:** 18-35 дней при стабильном Pine2AST и готовом PineLib P0.

---

## 28. Порядок реализации крупными блоками для агентов

### Блок A — skeleton и инфраструктура

1. Создать пакет.
2. Создать AST schema adapter.
3. Создать visitor.
4. Создать CodeEmitter.
5. Создать ImportManager.
6. Создать TranslationContext.
7. Добавить CLI `validate` и `translate`.

**Результат:** можно перевести пустой/минимальный AST в Python skeleton.

### Блок B — expressions и variables

1. Literals.
2. Identifiers.
3. Member access.
4. Calls.
5. Binary/unary/ternary.
6. Var declarations.
7. Reassignments.
8. Tuple declarations.

**Результат:** простые indicator scripts генерируются.

### Блок C — control flow/functions

1. If.
2. Switch statement/expression.
3. For/while.
4. Break/continue.
5. Function declarations.
6. Local scopes.

**Результат:** сложная логика фильтров и функций генерируется.

### Блок D — Pine-specific semantics

1. History reference.
2. Stateful call `state_id`.
3. `var`/`varip`.
4. UDT/enum.
5. Bool v6 validation.
6. Source map.

**Результат:** код соответствует Pine execution model.

### Блок E — strategy/request integration

1. `strategy()` declaration.
2. `strategy.entry/exit/order/close/cancel`.
3. `request.security` callable generation.
4. `syminfo/timeframe/barstate`.
5. Visual no-op recorder.

**Результат:** целевая стратегия запускается end-to-end.

### Блок F — full validation

1. Snapshot tests.
2. Compile tests.
3. Runtime smoke tests.
4. AVAX/SOL/XLM integration.
5. Coverage report.
6. Диагностический diff generated vs expected.

**Результат:** production-ready MVP.

---

## 29. Риски

| Риск | Вероятность | Влияние | Как снизить |
|---|---:|---:|---|
| Pine2AST schema нестабилен | средняя | высокое | adapter layer + schema version |
| Неверная series/current модель | высокая | критично | синхронизировать с PineLib contract |
| `request.security` сгенерирован как значение, а не expression | высокая | критично | обязательный lambda/callable contract |
| Потеря scope в functions/switch | средняя | высокое | scope tests |
| Конфликт имён | средняя | среднее | deterministic naming registry |
| Сгенерированный код нечитаем | средняя | среднее | templates + formatter |
| Unsupported визуальные функции ломают стратегию | средняя | среднее | no-op recorder |
| Нет source map | низкая | высокое | source map как обязательный DoD |

---

## 30. Definition of Done

1. Есть pip-installable пакет `ast2python`.
2. Есть CLI.
3. Есть стабильный AST schema adapter.
4. Есть полный набор snapshot tests.
5. Есть generated metadata/source map/coverage.
6. Есть интеграционный тест Pine2AST -> AST2Python -> PineLib.
7. Для целевой стратегии generated code не содержит ручных правок.
8. Любой unsupported feature выдаёт понятную ошибку до запуска backtest.
9. Сгенерированный код детерминированный.
10. Сгенерированный код можно использовать оптимизатором параметров без TradingView.

---

## 31. Runtime Contract reference

AST2Python обязан генерировать код строго под `runtime_contract.md` версии `1.4`.

Обязательная проверка генератора:

```python
assert target_contract_version == "1.4"
```

Generated module header:

```python
# Generated by AST2Python
# Runtime contract: pinelib-ast2python/1.4
```

При несовместимой версии PineLib runtime сгенерированный класс должен падать до начала backtest:

```python
if runtime.contract_version != "1.4":
    raise RuntimeContractError(
        f"Generated code requires runtime contract 1.4, got {runtime.contract_version}"
    )
```


## 32. Источники и ориентиры

- TradingView Pine Script v6 User Manual — Execution model
- TradingView Pine Script v6 User Manual — Operators / history-referencing operator
- TradingView Pine Script v6 User Manual — Other timeframes and data / request.security
- TradingView Pine Script v6 User Manual — Strategies
- TradingView Pine Script v6 Migration Guide — bool values cannot be na
- TradingView Pine Script v6 Reference Manual — built-ins
