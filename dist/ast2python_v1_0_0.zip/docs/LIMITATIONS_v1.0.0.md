# AST2Python v1.0.0 Limitations

This final release is intentionally conservative. Unsupported behavior must be diagnosed before generated code is used for backtests.

## Explicitly deferred

- Execution of external Pine libraries imported through `import ... as ...`; calls are recorded with `P2A_EXTERNAL_LIBRARY_CALL` diagnostics and return `na`.
- Request APIs beyond `request.security`; unsupported request calls emit `P2A_UNSUPPORTED_REQUEST`.
- Shape-preserving matrix literals; call-based `matrix.new` is supported.
- Full TradingView visual object behavior; generated code records visual/reference calls through PineLib-compatible recorders where available.
- Non-P0 strategy APIs; unsupported strategy APIs emit diagnostics instead of silently lowering.

## Supported release-candidate guarantees

- Deterministic code generation for identical AST input.
- Generated modules do not call `commit_current()` or execute broker fills.
- Source-map, coverage and metadata artifacts are emitted for every translation result.
