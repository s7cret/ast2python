# AST2Python v0.8.0 Coverage Notes

## Enforced gates

- `compileall ast2python tests scripts`
- full `pytest -q` including Pine2AST golden-fixture integration
- `mypy ast2python tests scripts/build_release.py`
- release archive reproducibility through `scripts/build_release.py`

## Runtime integration coverage

- CLI `translate-many` writes `.py`, `.meta.json`, `.coverage.json` and `.sourcemap.json` for every input fixture.
- Generated module snapshots are compared against direct API translation output for deterministic parity.
- PineLib import fallback checks `/home/moltbot1/pinelib` without modifying that repository.

## Explicit limitations

- Unsupported request APIs are diagnostic-only before runtime.
- External libraries are recorded with alias/member metadata and return `na`; execution of external Pine libraries is out of scope.
- Shape-preserving matrix literals remain unsupported; call-based `matrix.new` lowering is covered.
