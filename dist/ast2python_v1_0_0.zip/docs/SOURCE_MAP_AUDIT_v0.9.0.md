# Source Map Audit v0.9.0

The release-candidate audit asserts:

- every translation result has `.sourcemap.json` metadata naming;
- source-map entries include `python_line` and `pine_line`;
- generated executable line source-map ratio stays at or above 0.95 on real Pine2AST fixtures;
- coverage reports include generation ratio, builtin usage, node-kind counts and unsupported-node catalog.

These checks protect deterministic debugging artifacts required by runtime contract `1.4`.
