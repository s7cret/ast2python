# AST2Python v0.7.0

Target-strategy readiness/recovery release for runtime contract `1.4`.

## Added

- Pine2AST golden-fixture integration tests for collections, imports, strategy exits and real-world strategy state.
- Array/map/matrix call lowering via PineLib reference classes for supported constructor/access/mutation calls.
- Import alias metadata and external-library call recorder diagnostics.
- P0 `strategy.*` API lowering guardrails with explicit diagnostics for unsupported strategy APIs.
- Alert and alertcondition recorder generation.
- Extended input metadata for `input.time`, `input.source`, session/timeframe and UI edge fields.

## Hardened

- Unsupported request APIs now produce `P2A_UNSUPPORTED_REQUEST` diagnostics before runtime.
- Source-map executable-line ratio remains covered by real Pine2AST fixtures.
- Generated coverage metadata records used builtins, node kinds, unsupported catalog and import aliases.

## Deferred limitations

- Shape-preserving matrix literals remain unsupported; `matrix.new` call lowering is supported.
- External Pine libraries are recorded and diagnosed; AST2Python does not execute third-party library code.
- Full non-P0 strategy APIs remain intentionally outside v0.7.0.
