# AST2Python v1.0.0 Release Notes

AST2Python v1.0.0 finalizes the Pine2AST → Python generator for PineLib runtime contract `1.4`.

## Highlights

- Deterministic module, metadata, coverage and source-map generation.
- Pine2AST golden-fixture integration for indicators, strategies, collections, imports, inputs, alerts and selected real-world smoke programs.
- P0 strategy order API lowering with explicit diagnostics for unsupported strategy APIs.
- `request.security` callable-context lowering plus diagnostics for unsupported request APIs.
- PineLib v1.0 import/smoke compatibility without modifying PineLib.
- Reproducible release archive: `dist/ast2python_v1_0_0.zip`.

## Limitations

External libraries, non-`request.security` request APIs, shape-preserving matrix literals and full visual-object behavior remain documented limitations, not silent claims.
