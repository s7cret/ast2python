# AST2Python v0.8.0

Pipeline parity and runtime-integration hardening release.

## Added

- `ast2python translate-many` CLI command for deterministic multi-fixture translation.
- Integration tests proving CLI/API generated module snapshot parity.
- Coverage documentation for runtime integration, source-map and unsupported-node policy.

## Hardened

- Generator milestone metadata now follows package version automatically.
- PineLib v1.0 import/smoke compatibility remains verified without modifying PineLib.
- Strategy metadata and diagnostics envelopes are asserted by integration tests.

## Deferred limitations

- External library execution remains recorder-only.
- Full request API parity beyond `request.security` remains explicit diagnostics.
- Matrix literals remain unsupported until PineLib exposes shape-preserving literal constructors.
