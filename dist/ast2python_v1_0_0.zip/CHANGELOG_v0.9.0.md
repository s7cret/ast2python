# AST2Python v0.9.0

Release-candidate hardening.

## Added

- Public API stability tests and semver-aligned package metadata.
- Limitations and source-map audit documentation.
- Performance smoke test over real Pine2AST fixtures.
- Release manifest validation test.

## Hardened

- Source-map/report metadata shape is asserted before release.
- Type-check gate covers package, tests and release builder.

## Deferred limitations

See `docs/LIMITATIONS_v0.9.0.md`.
