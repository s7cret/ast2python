# AST2Python v1.0.0 Final Audit

## Scope

Finalization only. No risky feature dump was added after v0.9.0. The release preserves runtime contract `1.4` behavior and makes limitations explicit.

## Gates

The release script runs sequentially:

1. `python -m compileall ast2python tests scripts`
2. `pytest -q`
3. `mypy ast2python tests scripts/build_release.py`
4. `RELEASE_MANIFEST=RELEASE_MANIFEST_v1.0.0.json python scripts/build_release.py`
5. `sha256sum dist/ast2python_v1_0_0.zip`

## Audit findings

- Generated code remains deterministic for identical AST input.
- Unsupported features fail or diagnose before runtime; no placeholder runtime crashes are intentionally introduced.
- Generated code does not own `commit_current()` or broker fills.
- PineLib and Pine2AST repositories were not modified.
- Release archive is produced by the deterministic zip builder with fixed timestamps.

## Explicit deferred limitations

See `docs/LIMITATIONS_v1.0.0.md`.
