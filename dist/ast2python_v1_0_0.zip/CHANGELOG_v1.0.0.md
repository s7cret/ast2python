# AST2Python v1.0.0

Finalization release for runtime contract `1.4`.

## Added

- Final audit report: `FINAL_AUDIT_v1.0.0.md`.
- Release notes: `RELEASE_NOTES_v1.0.0.md`.
- v1.0 limitations and source-map audit docs.

## Hardened

- Version, README, manifest and release script aligned to `1.0.0`.
- Release gates remain compileall, pytest, mypy and deterministic archive build.

## Deferred limitations

See `docs/LIMITATIONS_v1.0.0.md`.
